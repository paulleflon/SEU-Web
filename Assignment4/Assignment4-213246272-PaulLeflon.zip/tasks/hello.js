export default {
	index: 0,
	name: 'Hello, Node.js!',
	run: () => {
		console.log('Hello, Node.js!');
	}
}